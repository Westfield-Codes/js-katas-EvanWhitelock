/* Variable and Alert Katas */
// These katas do not involve functions and are very basic. 

/* COLOR KATAS */

/* Var Alert */
// make a string variable for a color, set it equal to your favorite
// alert the message" "My favorite color is " plus the color

/* Var Alert Prompt */
// make a string variable for color, prompt the user for their favorite
// alert color " is a nice color!"

/* Var Alert Prompt Conditional */
// make a variable for color, prompt the user for their favorite
// if user enters "black" alert "Black is not really a color." 
// otherwise alert color " is a nice color!"
