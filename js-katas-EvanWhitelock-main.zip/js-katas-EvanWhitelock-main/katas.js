/* Variable and Alert Katas */
// These katas do not involve functions and are very basic. 
// "String variable" and "integer variable" are created the same way. 

/* COLOR KATAS */

/* Var Alert */
// make a string variable named color, set it equal to your favorite color.
// alert the message" "My favorite color is " plus the variable name outside quotes.

/* Var Alert Prompt */
// make a string variable for color, prompt the user for their favorite color.
// alert color " plus is a nice color!"

/* Var Alert Prompt Conditional */
// make a string variable for color, prompt the user for their favorite
// if user enters "black" alert "Black is not really a color." 
// otherwise alert color " is a nice color!"

/* AGE KATAS */

/* Var Alert */
// make an integer variable for age, set it equal to your age
// make a string variable for name, set it to your name
// alert name is age years old

/* Var Alert Prompt */
// make an integer variable for age, prompt user for their age
// make a string variable for name, prompt user for their name
// alert name is age years old


/* Var Alert Prompt Conditional */
// make an integer variable for age, prompt user for it
// make a string variable for name, prompt user for it
// if age is greater than 16, alert "you don't look that old!"
// otherwise alert name is age years old


/* ICE CREAM KATAS */

/* Var Alert Prompt */
// make a string variable for ice cream flavor, prompt user for it
// make an integer variable for scoops, prompt user for it
// alert "You want " scoops "scoops of " flavor

/* Var Alert Prompt Conditional */
// make a string variable for ice cream flavor, prompt user for it
// make an integer variable for scoops, prompt user for it
// if scoop is creater than three, alert ("Max 3 scoops!")
// otherwise alert "You want " scoops "scoops of " flavor

/* PET KATAS */

/* Var Alert Prompt */
// make a variable for pet type, prompt user for it 
// make a variable for pet name, prompt user for it
// alert "You have a pet type named pet name 

/* Var Alert Prompt Conditionals */
// make a variable for pet type, prompt user for it 
// make a variable for pet name, prompt user for it
// alert "You have a pet type named pet name 
// if pet is a dog, say "I like dogs, too!"
// if it is a cat, say "I'm allergic to cats"
// If it is not a dog or a cat, say "what an interesting pet!"